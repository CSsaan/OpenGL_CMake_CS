/**
 * MyHistogram.hpp skeleton
 * Contributors:
 *      * CS
 * Licence:
 *      * MIT
 */

#pragma once

#include <memory>
#include "Application.hpp"
#include "Shader.hpp"
#include "Texture.hpp"
#include "ComputeShader.hpp"

#define GLM_ENABLE_EXPERIMENTAL
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/matrix_operation.hpp>

#include "asset.hpp"
#include "glError.hpp"

class MyHistogram : public Application {
public:
    MyHistogram();
    ~MyHistogram();

protected:
    void loop() override;
    void processInput(GLFWwindow *window);

private:
    unsigned int VAO{0};
    int fCounter = 0;
    float deltaTime = 0.0f;
    float lastFrame = 0.0f;
    void InitComputeShader();
    GLuint histogramBuffer;
    unsigned char* pixels = nullptr;
    int width, height, components;
    unsigned int inputTexture;
    std::unique_ptr<ComputeShader> computeShader = std::make_unique<ComputeShader>(SHADER_DIR "/histogram/ComputeShader.comp");
    std::unique_ptr<Shader> shaderProgram = std::make_unique<Shader>(SHADER_DIR "/Basic.vert", SHADER_DIR "/Basic.frag");
    glm::vec2 lowHigtThreads{0.3f, 0.6f};
    void render();
};
